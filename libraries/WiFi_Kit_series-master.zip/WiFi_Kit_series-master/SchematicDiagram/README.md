# About Schematic diagram

- [WIFI Kit 8](WIFI_Kit_8_Schematic_diagram.PDF)
- [WIFI Kit 32](WIFI_Kit_32_Schematic_diagram.PDF)
- [WIFI LoRa 32(433.470-510MHz)](WIFI_LoRa_32(433_470-510 version)Schematic_diagram.PDF)
- [WIFI LoRa 32(868-915MHz)](WIFI_LoRa_32(868-915version)Schematic_diagram.PDF)

all Schematic diagram didn't include impedance matching components value.
